import React, {useState} from 'react';
import sCss from "./SearchImg.module.css";
import axios from "axios";
import {useHistory} from "react-router-dom";
import icon from "./Icons/search.svg";



function SearchImg() {
    const history = useHistory();
    const [input, setInput] = useState("");
    const [result, setResult] = useState([]);


    const handleChange = (e) => {
        setInput(e.target.value)
    }

    const search = () => {
        axios.get(`https://api.unsplash.com/search/photos?client_id=YDtb5JpYfGWSvcjjMHncluae33D2iDuyZnxaipAY3WA&query=${input}`)
        .then((res) => {
            setResult(res.data.results);
            console.log(res)
        })
    }

    let view = (r) => {
        console.log(r)
        history.push({
            pathname:"/edit",
            state : {path : r}
        })
      
    }

    return (
        <>
        <h1 style={{textAlign:"center", fontFamily:"sans-serif"}}>Search Images</h1>
        <div className={sCss.search} >
            <input type="text" onChange={handleChange} value={input} />
            <img onClick={search}  src={icon} alt=""/>
        </div>
        <div className={sCss.imgs}>
            {
                result.map((r, i) => {
                    return (
                    <div className={sCss.perImage} key={r.id}>
                        <img src={r.urls.regular} alt="" width="300" crossOrigin="crossorigin"  />
                        <button onClick={() => view(r.urls.small)} >Caption</button>
                    </div>
                    )
                })
            }
    
        </div>
        </>
    )
}

export default SearchImg;
