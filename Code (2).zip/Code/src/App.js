import React from 'react';
import SearchImg from "./SearchImg";
import {Switch, Route} from "react-router-dom";
import EditImage from "./EditImage";



function App() {

  return (
    <div>
      
    <Switch>
      <Route path="/" exact component={SearchImg} /> 
      <Route path="/edit" component={EditImage} /> 
    </Switch>

    </div>
  )
}

export default App;
