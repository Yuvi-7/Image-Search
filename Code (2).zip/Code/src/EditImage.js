import React, {useState, useEffect} from 'react';
import eCss from "./EditImage.module.css";
import { useLocation } from "react-router-dom";
import {fabric} from "fabric";



function EditImage() {
    const [canvas, setCanvas] = useState("");  
    const [input, setInput] = useState("");
    const location = useLocation();


 
    const handleChange = (e) => {
        setInput(e.target.value)
    }
    
     useEffect(() => {
        setCanvas(initCanvas);
        },[]);
      

        const initCanvas = () => (
            new fabric.Canvas('canvas', {
                width: 500,
                height: 600,
                backgroundImage:location.state.path
              
            })
            
        );  
 
    // Circle
    const addCir = (canvi) => {
        const cir = new fabric.Circle({
            radius: 20, fill: 'green', left: 100, top: 100
        })
        canvi.add(cir);
        canvi.renderAll();
    }

    //Triangle
    const addTri = (canvi) => {
        const tri = new fabric.Triangle({
            width: 100, height: 130, fill: 'blue', left: 50, top: 50
        })
        canvi.add(tri);
        canvi.renderAll();
    }

    //Rectangle
    const addRect = (canvi) => {
        const rect = new fabric.Rect({
            width: 200, height: 100, fill: 'skyblue', left:50, top: 50
        })
        canvi.add(rect);
        canvi.renderAll();
    }

    //Polygon
    const addPoly = (canvi) => {
        var poly = new fabric.Polygon([
            { x: 200, y: 10 },
            { x: 250, y: 50 },
            { x: 250, y: 180},
            { x: 150, y: 180},
            { x: 150, y: 50 }], {
                fill: 'green'
            });
        canvi.add(poly);
        canvi.renderAll();
    }


    //Text
    const text = (canvi) => {
            var txt = new fabric.Text(input, {
                fontSize:40
            })
            canvi.add(txt)
            canvi.renderAll()
    } 

    const down = (canvas) =>{
        var url = canvas.toDataURL("image/png");
       
        console.log(url);
    }

    return (
     
       <div className={eCss.main}>        
           <h1 style={{fontFamily:"sans-serif"}}>Add Caption</h1>

           <div className={eCss.both}>
            <div className={eCss.canvas}>
            <canvas id="canvas"  width='900' style={{margin:"auto"}} />
            </div>


        <div className={eCss.btns}>
                <div className={eCss.input}>
                    <input type="text" onChange = {handleChange} value={input} />
                    <button onClick={() => text(canvas)} >Add Caption</button>
                </div>
                
           <div className={eCss.bt}>
                <button onClick={() => addCir(canvas)}>Circle</button>   
                <button onClick={() => addTri(canvas)}>Triangle</button>
                <button onClick={() => addRect(canvas)}>Rectangle</button>
                <button onClick={() => addPoly(canvas)}>Polygon</button>
           </div>

           <div className={eCss.down}>
                <button onClick={() => down(canvas)} >Download</button>
           </div>

        </div>
        </div>
             
       </div>
    )
}

export default EditImage;
